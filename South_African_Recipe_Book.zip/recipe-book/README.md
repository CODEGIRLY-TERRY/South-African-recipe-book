
# 🇿🇦 South African Recipe Book (Frontend Project)

This is a simple, visually appealing frontend web app that lets you view and add South African recipes using HTML, CSS, and JavaScript. Recipes are saved in your browser's local storage.

## 🍲 Features
- Preloaded with traditional South African recipes
- Add your own recipes with images
- Delete recipes you no longer need
- Responsive, user-friendly design

## 🛠 Tech Stack
- HTML
- CSS
- JavaScript
- Browser localStorage

## 🧑🏾‍🍳 How to Run
1. Download the project
2. Open `index.html` in your browser
3. Start cooking!

## 📸 Preview
Includes images for:
- Bobotie
- Chakalaka
- Bunny Chow
- Malva Pudding
- Vetkoek

## 📄 License
MIT License
