
document.addEventListener('DOMContentLoaded', () => {
  const recipeForm = document.getElementById('recipeForm');
  const recipeList = document.getElementById('recipeList');

  const defaultRecipes = [
    {
      title: "Bobotie",
      instructions: "Mix spiced minced beef with chutney and soaked bread. Top with egg mixture and bay leaves. Bake until golden.",
      image: "assets/bobotie.jpg"
    },
    {
      title: "Chakalaka",
      instructions: "Fry onions, peppers, carrots, and garlic. Add baked beans, curry powder, and simmer. Serve cold or hot.",
      image: "assets/chakalaka.jpg"
    },
    {
      title: "Bunny Chow",
      instructions: "Hollow out a quarter loaf of white bread and fill with spicy beef or bean curry. Eat with hands.",
      image: "assets/bunnychow.jpg"
    },
    {
      title: "Malva Pudding",
      instructions: "Bake sponge pudding made with apricot jam. Pour cream-based sauce over hot pudding. Serve with custard.",
      image: "assets/malvapudding.jpg"
    },
    {
      title: "Vetkoek",
      instructions: "Deep-fry yeast dough until golden. Fill with curried mince or serve with syrup or jam.",
      image: "assets/vetkoek.jpg"
    }
  ];

  const loadRecipes = () => {
    const existing = localStorage.getItem('recipes');
    if (!existing) {
      localStorage.setItem('recipes', JSON.stringify(defaultRecipes));
    }

    const recipes = JSON.parse(localStorage.getItem('recipes')) || [];
    recipeList.innerHTML = '';
    recipes.forEach((recipe, index) => {
      const div = document.createElement('div');
      div.className = 'recipe-card';
      div.innerHTML = `
        ${recipe.image ? `<img src="${recipe.image}" alt="${recipe.title}">` : ''}
        <h3>${recipe.title}</h3>
        <p>${recipe.instructions}</p>
        <button onclick="deleteRecipe(${index})">Delete</button>
      `;
      recipeList.appendChild(div);
    });
  };

  window.deleteRecipe = (index) => {
    const recipes = JSON.parse(localStorage.getItem('recipes')) || [];
    recipes.splice(index, 1);
    localStorage.setItem('recipes', JSON.stringify(recipes));
    loadRecipes();
  };

  recipeForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const title = document.getElementById('recipeTitle').value;
    const instructions = document.getElementById('recipeInstructions').value;
    const image = document.getElementById('recipeImage').value;
    const newRecipe = { title, instructions, image };

    const recipes = JSON.parse(localStorage.getItem('recipes')) || [];
    recipes.push(newRecipe);
    localStorage.setItem('recipes', JSON.stringify(recipes));

    recipeForm.reset();
    loadRecipes();
  });

  loadRecipes();
});
